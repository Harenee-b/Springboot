package com.wipro;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.dao.DataAccessException;

import com.wipro.entity.Address;
import com.wipro.entity.Department;
import com.wipro.entity.Employee;
import com.wipro.entity.Order;
import com.wipro.entity.Product;
import com.wipro.entity.Student;
import com.wipro.entity.User;

import jakarta.persistence.EntityManager;
//import jakarta.persistence.EntityTransaction;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@SpringBootApplication
public class SpringBootJpaAppApplication implements CommandLineRunner{

	@PersistenceContext
	private EntityManager entityManager;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaAppApplication.class, args);
	}

	@Override
	@Transactional
	public void run(String... args) throws Exception {
	try {
//			User user=new User("admin","admin123",LocalDate.of(2001, 04, 19), "Madurai", "sujee@gmail.com", 898891234246L);
//			EntityTransaction transaction=entitymanager.getTransaction();
//			transaction.begin();
//			entitymanager.persist(user);
//			entitymanager.flush();//optional-flush data into database
//			System.out.println("1 row added to the database");
//		}
//		catch(DataAccessException e) {
//			//entitymanager.getTransaction().rollback();
//			e.printStackTrace();
//		}

	/*	try {
			int id=1;
			User user=entitymanager.find(User.class, id);
			System.out.println(user);
			user.setAddress("Manali");
			entitymanager.merge(user);
			entitymanager.flush();
			System.out.println("User with ID "+ id+" updated");
			System.out.println(user);
		}
		catch(DataAccessException e) {
			entitymanager.getTransaction().rollback();
		e.printStackTrace();
		}
		*/

/*
		try {
			//JPQL
			String query = "select u from User u";
			TypedQuery<User> tq = entityManager.createQuery(query, User.class);
			List<User> userList = tq.getResultList();
			userList.forEach(System.out::println);
		}catch(DataAccessException e) {
			e.printStackTrace();
		}
		
		try {
			int id=1;
			User user = entityManager.find(User.class, id);
			if(user ==null) {
				throw new SQLException("Invalid Id");
			}
			
			entityManager.remove(user);
			System.out.println("User: "+ id+ " deleted");
		}catch(DataAccessException e) {
			e.printStackTrace();
		}
		
		System.out.println("After deletion..");
		
		try {
			//JPQL
			String query = "select u from User u";
			TypedQuery<User> tq = entityManager.createQuery(query, User.class);
			List<User> userList = tq.getResultList();
			userList.forEach(System.out::println);
		}catch(DataAccessException e) {
			e.printStackTrace();
		}
		*/
		
/*	try {
			Address address =new Address("12/34","Chennai");
			Student student =new Student("Smith",LocalDate.of(2001, 12, 03),address);
			
			entityManager.persist(student);
			entityManager.flush();
			System.out.println("Both Student and Address objects are persisted into database.");
			*/
			
	/*		Student student = entityManager.find(Student.class, 1);
			System.out.println(student);
			Address address=student.getAddress();
			System.out.println(address);
		
		System.out.println(address.getStudent());
		}catch(DataAccessException e){
			e.printStackTrace();
			}
			*/
		
	//	Department department = new Department("Accounts");
	//	Employee employee1 = new Employee("Smith",department);
	//	Employee employee2 = new Employee("Sachin",department);
		
		
		//persist owning side, i.e employee bean
	//	entityManager.persist(employee1);
	//	entityManager.persist(employee2);
	//	entityManager.flush();
		
	//	System.out.println("Data persisted into database");


		//Department department=entityManager.find(Department.class, 1);
		//System.out.println(department);

		//List<Employee> employeeList = department.getEmployeeList();
		//employeeList.forEach(System.out::println);

		Product product1 = new Product(1,"Apple iPhone 14");
		Product product2 = new Product(1,"Apple iPhone 14");
		Set<Product> productSet = new HashSet<>();
		productSet.add(product1);
		productSet.add(product2);
		
		System.out.println(productSet.size());
		System.out.println(product1.hashCode());
		System.out.println(product2.hashCode());
		productSet.forEach(System.out::println);
		
		Order order = new Order(LocalDate.of(2024, 8, 12),168500.00,productSet);
		
		entityManager.persist(order);
		System.out.println("Order saved");

		
		
		}catch(DataAccessException e) {
			e.printStackTrace();
		}
}}
	

	


