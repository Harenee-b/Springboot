package com.wipro.app;

import java.util.HashSet;
import java.util.Set;

import com.wipro.entity.Product;

public class ProductDemo {



	public static void main(String[] args) {
		Product product1 = new Product(1,"Apple iPhone 14");
		Product product2 = new Product(1,"Apple iPhone 14");
		Set<Product> productSet = new HashSet<>();
		productSet.add(product1);
		productSet.add(product2);
		
		System.out.println(productSet.size());
		System.out.println(product1.hashCode());
		System.out.println(product2.hashCode());
		productSet.forEach(System.out::println);


	}

}
