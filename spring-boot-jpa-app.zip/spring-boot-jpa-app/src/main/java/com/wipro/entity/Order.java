package com.wipro.entity;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
@Entity
@Table(name="order")
public class Order {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@Column(name="orderid")
	private Integer orderId;
	private LocalDate orderDate;
	@Column(nullable=false)
	private Double orderAmount;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="order_product",
	                 joinColumns = {@JoinColumn(name="order_id")},
	                 inverseJoinColumns = {@JoinColumn(name="product_id")})
	private Set<Product> productSet;
	
	public Order() {
		
	}
	public Order(LocalDate orderDate, Double orderAmount) {
		super();
		this.orderDate = orderDate;
		this.orderAmount = orderAmount;
	}
	
	
	public Order(LocalDate orderDate, Double orderAmount, Set<Product> productSet) {
		super();
		this.orderDate = orderDate;
		this.orderAmount = orderAmount;
		this.productSet = productSet;
	}
	public Order(Integer orderId, LocalDate orderDate, Double orderAmount, Set<Product> productSet) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.orderAmount = orderAmount;
		this.productSet = productSet;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public Double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public Set<Product> getProductSet() {
		return productSet;
	}
	public void setProductSet(Set<Product> productSet) {
		this.productSet = productSet;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", orderAmount=" + orderAmount + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(orderAmount, orderDate, orderId, productSet);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return Objects.equals(orderAmount, other.orderAmount) && Objects.equals(orderDate, other.orderDate)
				&& Objects.equals(orderId, other.orderId) && Objects.equals(productSet, other.productSet);
	}
	
	

}
