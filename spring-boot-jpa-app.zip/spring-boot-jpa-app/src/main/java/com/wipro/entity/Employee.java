package com.wipro.entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
//Employee is owning side
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer empno;
	private String ename;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "deptno")
	private  Department department;
	
	
	public Employee() {
		
	}
	
	public Employee(Integer empno, String ename) {
		this.empno=empno;
		this.ename=ename;
	}


	public Employee( String ename, Department department) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.department = department;
	}


	public Integer getEmpno() {
		return empno;
	}
	public void setEmpno(Integer empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", ename=" + ename + "]";
	}
	
	
	
}
