package com.wipro.entity;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
// Department 1 ---------------M  Employee
/*Department is one side,one side is the inverse side
*
* Employee is many side, many side is always the owning side
*/
@Entity
public class Department {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private Integer deptno;
	private String dname;
	@OneToMany(mappedBy = "department")
	List<Employee> employeeList;
	
	public Department() {
		
	}


public Department(String dname) {
		super();
		this.dname = dname;
	}




public Department(Integer deptno, String dname) {
		super();
		this.deptno = deptno;
		this.dname = dname;
	}


	public Department(Integer deptno, String dname, List<Employee> employeeList) {
		super();
		this.deptno = deptno;
		this.dname = dname;
		this.employeeList = employeeList;
	}
	public Integer getDeptno() {
		return deptno;
	}
	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public List<Employee> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	@Override
	public String toString() {
		return "Department [deptno=" + deptno + ", dname=" + dname + "]";
	}
	

}
