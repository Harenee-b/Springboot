package com.wipro.model;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor

public class Customer {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long custId;
    
    private String adharCard;
    private String customerName;
    private String address;
    private String email;
    private String mobile;

    @OneToMany(mappedBy = "customer")
    private List<OrderMaster> orders;

    public Customer() {
    	
    }
}
