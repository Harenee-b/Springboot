package com.wipro.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.wipro.bean.Car;
import com.wipro.bean.Engine;

@Configuration
public class CarConfiguration {

	@Bean(value = "engineBean")
	public Engine  getEngine() {
		return new Engine(123456789L,"Petrol",2900.0);
	}
	
	@Bean(value = "carBean")
	public Car getCar() {
		return new Car("Merceded Benz","X1",getEngine());
	}
	
	
}
