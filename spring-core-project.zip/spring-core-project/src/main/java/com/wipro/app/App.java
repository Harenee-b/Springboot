package com.wipro.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.AbstractApplicationContext;

import com.wipro.bean.Car;
import com.wipro.config.CarConfiguration;


@ComponentScan(basePackages = "com.wipro")
public class App {
	public static void main( String[] args ){
		try {
			ApplicationContext context = new AnnotationConfigApplicationContext(CarConfiguration.class);

			Car myCar = (Car)context.getBean("carBean");
			System.out.println(myCar);

			
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
