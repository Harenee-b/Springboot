package com.wipro;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.wipro.mapper.CustomerRowMapper;
import com.wipro.model.Customer;

@SpringBootApplication
public class SpringJdbcProjectApplication implements CommandLineRunner{

	private Logger logger = LoggerFactory.getLogger(SpringJdbcProjectApplication.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	
	

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	private CustomerRowMapper customerRowMapper;

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcProjectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Creating customers table...");

//		jdbcTemplate.execute("DROP TABLE customers IF EXISTS");
//		jdbcTemplate.execute("CREATE TABLE customers(" +
//				"id SERIAL, first_name VARCHAR(255), last_name VARCHAR(255))");
		
//		jdbcTemplate.execute("CREATE TABLE customers(" +
//				"id NUMBER(4), first_name VARCHAR2(20), last_name VARCHAR2(20))");

//		logger.info("Table created..");

		jdbcTemplate.update("INSERT INTO CUSTOMERS VALUES (?, ?, ?)", 3, "Ravi", "Kumar");
		jdbcTemplate.update("INSERT INTO CUSTOMERS VALUES (?, ?, ?)", 4, "Priya", "Rao");

		logger.info("Inserted 2 more rows..");

		SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("id", 1);

		String customerFirstName = namedParameterJdbcTemplate.queryForObject(
				"SELECT FIRST_NAME FROM CUSTOMERS WHERE ID = :id", namedParameters, String.class);
		System.out.println("Customer First Name: "+customerFirstName);




		System.out.println("Customer details..");
		String queryOne = "SELECT * FROM CUSTOMERS WHERE ID = ?";
//		Customer customer = jdbcTemplate.queryForObject(queryOne, new CustomerRowMapper(), 1);
		Customer customer = jdbcTemplate.queryForObject(queryOne,customerRowMapper, 1);
		System.out.println(customer);
		
		

		System.out.println("Lsit of customers..");
		String queryAll = "SELECT * FROM CUSTOMERS";
		List<Customer> customerList = jdbcTemplate.query(queryAll, customerRowMapper);
		customerList.forEach(System.out::println);

//		String deleteSQL = "DELETE FROM CUSTOMERS WHERE ID =?";
//		int n = jdbcTemplate.update(deleteSQL,2);
//		if(n>0) {
//			System.out.println("Customer with ID: "+ 2+ " deleted");
//		}else {
//			System.out.println("Unable to delete the customer");
//		}
//
//		System.out.println("List of customer ..");
//		customerList = jdbcTemplate.query(queryAll, customerRowMapper);
//		customerList.forEach(System.out::println);
	}

}
