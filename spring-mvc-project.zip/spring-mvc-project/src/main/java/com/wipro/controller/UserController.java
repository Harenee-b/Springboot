package com.wipro.controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.wipro.model.User;
@RestController
@RequestMapping("/uc")
public class UserController {
	//API end-point:  http://localhost:9090/uc/hello
	@GetMapping("/hello")
	public String sayHello() {
		return "Good Morning!";
	}
	//http://localhost:9090/uc/users
	@GetMapping("/users")
	public User getUser(@RequestBody User user ){
		user.setPassword("xxx");
		return user;
	}
	//http://localhost:9090/uc/users
	@PostMapping("/users")
	public String addUser(@RequestBody User user ){
		//TODO ADDING user object to database
		return  "userId: " + user.getId()+ " added to database";
	}
	//http://localhost:9090/uc/users
	@PutMapping("/users")
	public String updateUser(@RequestBody User user ){
		//TODO UPDATING user object in database
		return  "userId: " + user.getId()+ " updated in the database";
	}
	//http://localhost:9090/uc/users
	@DeleteMapping("/users")
	public String deleteUser(@RequestBody User user ){
		//TODO DELETING user object from database
		return  "userId: " + user.getId()+ " deleted from database";
	}
}
