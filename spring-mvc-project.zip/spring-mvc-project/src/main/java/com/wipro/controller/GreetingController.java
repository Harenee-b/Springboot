package com.wipro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/hc")

public class GreetingController {
    
	//http://localhost:9090/greeting?batch=562467
	@GetMapping("/greeting")
	public ModelAndView greeting(@RequestParam(name="batch")String batch,Model model) {
	//model.addAttribute("batch",batch);
		//return "greeting";
		
		 ModelAndView mav = new ModelAndView("hello","batch", batch);
		 mav.addObject("sample", "Sample attribute");
		 return mav;

}
	
	//http://localhost:9090/hello?fname=Harenee&sname=B
	@GetMapping("/hello")
	public String greeting(@RequestParam(name="fname")String fname, @RequestParam(name="sname")String sname,Model model) {
		 model.addAttribute("fname",fname);
		 model.addAttribute("sname",sname);
		 return "hello";
	}
	
	//PathVariable example
		//http://localhost:9090/hc/pv/24NAG2088
		@GetMapping("/pv/{pth}")
		public String pathVariableExample(@PathVariable(name = "pth") String pth, Model model) {
			model.addAttribute("pth",pth);
			return "hellopth";
		}

}
