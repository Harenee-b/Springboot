package com.wipro;

public class OrderDetail {

	private int orderId;
	private String itemName;
	private long unitPrice;
	private int quantity;
	private long itemTotal;
	
}
