package com.wipro;

public enum Status {

}
