package com.wipro;

public class Customer {

	private int custId;
	private long adharCard;
	private String customerName;
	private String address;
	private String email;
	private long mobile;
	
	
	
	public Customer() {
		
	}
}
