package com.wipro;

import java.time.LocalDate;

public class OrderMaster {

	private int orderId;
	private double orderAmount;
	private LocalDate orderDate;
	private LocalDate shipmentDate;
	private Status status;
	
}
